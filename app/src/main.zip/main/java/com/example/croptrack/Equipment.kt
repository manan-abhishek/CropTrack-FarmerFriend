package com.example.croptrack

data class Equipment(
    val name: String,
    val description: String,
    val imageResId: Int
)
